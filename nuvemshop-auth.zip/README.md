# Nuvemshop OAuth Token API

Essa API recebe o `code` da Nuvemshop via URL e retorna o `access_token` usando a rota `/oauth?code=...`.

Hospede no Render e use como backend seguro para seu app da Nuvemshop.
